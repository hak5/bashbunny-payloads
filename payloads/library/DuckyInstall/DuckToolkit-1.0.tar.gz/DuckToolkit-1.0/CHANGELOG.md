# Change Log

## [1.0.0](https://github.com/kevthehermit/DuckToolkit/tree/1.0.0) (2017-02-28)
 - New language format
 - Support for bashbunny (hak5)
 - Library wrapper for use on bashbunny

## [0.9.2](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-09-26)
 - Fixed language issues

## [0.9.1](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-09-26)
 - Added Swedish language
 - Added PAUSE & BREAK
 - Added Replay

## [0.9](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-11-12)
- Correct the implementation of DEFAULT_DELAY

## [0.8](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-09-05)
- Fix null padding for low delay values

## [0.7](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-09-05)
- Added CH language support.

## [0.6](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-09-05)
- Added " " to DK, ES & IT language files.

## [0.5](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-08-30)
- Add . to Danish language file

## [0.4](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-08-30)
- Add additional languages

## [0.3](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-08-30)
- Add additional languages

## [0.2](https://github.com/kevthehermit/DuckToolkit/tree/0.2) (2016-08-30)
- Add pip installation

[Full Changelog](https://github.com/kevthehermit/DuckToolkit/compare/0.1...0.2)

## [0.1](https://github.com/kevthehermit/DuckToolkit/tree/0.1) (2016-08-30)
- First alpha release
